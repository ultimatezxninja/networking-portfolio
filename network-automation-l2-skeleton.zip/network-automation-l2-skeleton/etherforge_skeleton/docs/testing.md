# Testing Plan

## Unit tests

- Serialize header correctly.
- Parse header correctly.
- Reject frames that are too short.
- Detect duplicate sequence numbers.
- Verify QoS scheduling order.

## Integration tests

- Create namespace topology.
- Send frame from namespace 1 to namespace 2.
- Capture with tcpdump.
- Inspect frame in Wireshark.

## Fault injection ideas

Use `tc netem` later to simulate delay, jitter, and packet loss.
