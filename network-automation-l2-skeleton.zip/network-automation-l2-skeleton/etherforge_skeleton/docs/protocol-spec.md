# EtherForge Protocol Spec Draft

## Purpose

EtherForge is a learning-focused custom Layer 2 encapsulation protocol.

## Header V1 Draft

| Field | Size | Purpose |
|---|---:|---|
| Version | 1 byte | Protocol version |
| Flags | 1 byte | Control bits such as ACK or retransmit |
| QoS Class | 1 byte | Priority class for scheduling |
| Flow ID | 2 bytes | Identifies traffic flow |
| Sequence Number | 4 bytes | Reliability tracking |
| ACK Number | 4 bytes | Acknowledges received frames |
| Payload Length | 2 bytes | Payload size |
| Checksum | 2 bytes | Basic integrity check |

## QoS Classes

- 0: Best effort
- 1: Interactive
- 2: Control
- 3: Critical

## Next tasks

- Define exact byte layout.
- Add network byte order conversions.
- Add checksum validation.
- Add ACK and retransmission behavior.
