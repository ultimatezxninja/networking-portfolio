# Two-Node Demo Plan

1. Build project.
2. Start namespace topology.
3. Start receiver in ef-ns2.
4. Start sender in ef-ns1.
5. Capture traffic with tcpdump.
6. Show custom EtherType and header fields.
