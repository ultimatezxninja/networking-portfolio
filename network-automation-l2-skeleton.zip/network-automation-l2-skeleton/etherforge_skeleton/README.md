# EtherForge Skeleton

Custom Layer 2 encapsulation protocol starter.

This is a non-complete learning scaffold for a future C++ project using Linux raw Ethernet concepts.

## Planned ideas

- Custom EtherType
- Protocol header with version, flags, QoS class, flow ID, sequence number, ACK number, payload length, and checksum
- Sender / receiver split
- Parser / serializer layer
- Basic reliability logic
- QoS queues
- Linux namespace lab using veth pairs

## Build placeholder

```bash
cmake -S . -B build
cmake --build build
```

## Lab placeholder

```bash
sudo ./tools/topo-basic.sh
```
