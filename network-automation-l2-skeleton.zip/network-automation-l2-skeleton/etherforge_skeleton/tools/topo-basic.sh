#!/usr/bin/env bash
set -euo pipefail

# Basic two-node Ethernet lab using Linux namespaces and a veth pair.
# Run with sudo.

ip netns add ef-ns1 || true
ip netns add ef-ns2 || true

ip link add veth-ef1 type veth peer name veth-ef2 || true
ip link set veth-ef1 netns ef-ns1
ip link set veth-ef2 netns ef-ns2

ip netns exec ef-ns1 ip link set lo up
ip netns exec ef-ns2 ip link set lo up
ip netns exec ef-ns1 ip link set veth-ef1 up
ip netns exec ef-ns2 ip link set veth-ef2 up

ip netns exec ef-ns1 ip addr add 10.10.10.1/30 dev veth-ef1 || true
ip netns exec ef-ns2 ip addr add 10.10.10.2/30 dev veth-ef2 || true

echo "Topology ready: ef-ns1 <--> ef-ns2"
echo "Test with: sudo ip netns exec ef-ns1 ping 10.10.10.2"
