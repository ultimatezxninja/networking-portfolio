#!/usr/bin/env bash
set -euo pipefail

# Capture traffic from the namespace interface.
# Run with sudo after topo-basic.sh.

mkdir -p captures
ip netns exec ef-ns1 tcpdump -i veth-ef1 -nn -e -w captures/ef-ns1.pcap
