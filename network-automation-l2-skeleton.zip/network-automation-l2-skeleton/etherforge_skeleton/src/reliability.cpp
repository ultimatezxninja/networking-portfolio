#include "reliability.hpp"

namespace etherforge {

uint32_t ReliabilityTracker::next_sequence() {
    return next_sequence_number_++;
}

bool ReliabilityTracker::is_duplicate(uint32_t sequence_number) {
    return received_sequences_.count(sequence_number) > 0;
}

void ReliabilityTracker::mark_received(uint32_t sequence_number) {
    received_sequences_.insert(sequence_number);
}

} // namespace etherforge
