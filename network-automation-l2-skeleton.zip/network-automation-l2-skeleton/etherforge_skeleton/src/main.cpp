#include "frame_codec.hpp"
#include "protocol.hpp"
#include "qos.hpp"
#include "reliability.hpp"

#include <iostream>
#include <string>

int main() {
    etherforge::Frame frame;
    frame.header.version = 1;
    frame.header.qos_class = static_cast<uint8_t>(etherforge::QosClass::Control);
    frame.payload = {'h', 'e', 'l', 'l', 'o'};
    frame.header.payload_length = static_cast<uint16_t>(frame.payload.size());

    auto bytes = etherforge::serialize_frame(frame);

    std::cout << "EtherForge skeleton frame serialized. Bytes: " << bytes.size() << "\n";
    std::cout << "Next step: replace this demo with AF_PACKET send/receive logic.\n";

    return 0;
}
