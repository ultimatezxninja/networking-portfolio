#include "qos.hpp"
#include <stdexcept>

namespace etherforge {

void QosScheduler::enqueue(const Frame& frame) {
    switch (static_cast<QosClass>(frame.header.qos_class)) {
        case QosClass::Critical:
            critical_queue_.push(frame);
            break;
        case QosClass::Control:
            control_queue_.push(frame);
            break;
        case QosClass::Interactive:
            interactive_queue_.push(frame);
            break;
        case QosClass::BestEffort:
        default:
            best_effort_queue_.push(frame);
            break;
    }
}

bool QosScheduler::has_next() const {
    return !critical_queue_.empty() || !control_queue_.empty() ||
           !interactive_queue_.empty() || !best_effort_queue_.empty();
}

Frame QosScheduler::next_frame() {
    if (!critical_queue_.empty()) {
        Frame frame = critical_queue_.front();
        critical_queue_.pop();
        return frame;
    }
    if (!control_queue_.empty()) {
        Frame frame = control_queue_.front();
        control_queue_.pop();
        return frame;
    }
    if (!interactive_queue_.empty()) {
        Frame frame = interactive_queue_.front();
        interactive_queue_.pop();
        return frame;
    }
    if (!best_effort_queue_.empty()) {
        Frame frame = best_effort_queue_.front();
        best_effort_queue_.pop();
        return frame;
    }

    throw std::runtime_error("No frames available");
}

} // namespace etherforge
