#include "frame_codec.hpp"

#include <stdexcept>

namespace etherforge {

std::vector<uint8_t> serialize_frame(const Frame& frame) {
    std::vector<uint8_t> bytes;

    bytes.push_back(frame.header.version);
    bytes.push_back(frame.header.flags);
    bytes.push_back(frame.header.qos_class);

    // TODO: Convert multibyte fields to network byte order.
    // TODO: Add flow_id, sequence_number, ack_number, payload_length, checksum.
    // TODO: Append payload after header.

    bytes.insert(bytes.end(), frame.payload.begin(), frame.payload.end());
    return bytes;
}

Frame parse_frame(const std::vector<uint8_t>& bytes) {
    if (bytes.size() < 3) {
        throw std::runtime_error("Frame too short");
    }

    Frame frame;
    frame.header.version = bytes[0];
    frame.header.flags = bytes[1];
    frame.header.qos_class = bytes[2];

    // TODO: Parse remaining header fields.
    // TODO: Validate checksum.
    // TODO: Extract payload.

    if (bytes.size() > 3) {
        frame.payload.assign(bytes.begin() + 3, bytes.end());
    }

    return frame;
}

uint16_t calculate_checksum(const std::vector<uint8_t>& bytes) {
    uint32_t sum = 0;
    for (uint8_t byte : bytes) {
        sum += byte;
    }
    return static_cast<uint16_t>(sum & 0xFFFF);
}

} // namespace etherforge
