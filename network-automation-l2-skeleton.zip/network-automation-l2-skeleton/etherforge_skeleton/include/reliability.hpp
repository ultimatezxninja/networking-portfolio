#pragma once

#include "protocol.hpp"
#include <cstdint>
#include <set>

namespace etherforge {

class ReliabilityTracker {
public:
    uint32_t next_sequence();
    bool is_duplicate(uint32_t sequence_number);
    void mark_received(uint32_t sequence_number);

private:
    uint32_t next_sequence_number_ = 1;
    std::set<uint32_t> received_sequences_;
};

} // namespace etherforge
