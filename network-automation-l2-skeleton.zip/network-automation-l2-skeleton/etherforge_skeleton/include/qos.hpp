#pragma once

#include "protocol.hpp"
#include <queue>
#include <vector>

namespace etherforge {

enum class QosClass : uint8_t {
    BestEffort = 0,
    Interactive = 1,
    Control = 2,
    Critical = 3
};

class QosScheduler {
public:
    void enqueue(const Frame& frame);
    bool has_next() const;
    Frame next_frame();

private:
    std::queue<Frame> critical_queue_;
    std::queue<Frame> control_queue_;
    std::queue<Frame> interactive_queue_;
    std::queue<Frame> best_effort_queue_;
};

} // namespace etherforge
