#pragma once

#include "protocol.hpp"
#include <cstdint>
#include <vector>

namespace etherforge {

std::vector<uint8_t> serialize_frame(const Frame& frame);
Frame parse_frame(const std::vector<uint8_t>& bytes);
uint16_t calculate_checksum(const std::vector<uint8_t>& bytes);

} // namespace etherforge
