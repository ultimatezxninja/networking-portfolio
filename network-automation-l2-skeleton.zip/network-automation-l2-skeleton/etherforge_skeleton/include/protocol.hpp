#pragma once

#include <cstdint>
#include <vector>

namespace etherforge {

constexpr uint16_t ETHERFORGE_ETHERTYPE = 0x88B5; // Experimental placeholder

struct ProtocolHeader {
    uint8_t version = 1;
    uint8_t flags = 0;
    uint8_t qos_class = 0;
    uint16_t flow_id = 0;
    uint32_t sequence_number = 0;
    uint32_t ack_number = 0;
    uint16_t payload_length = 0;
    uint16_t checksum = 0;
};

struct Frame {
    ProtocolHeader header;
    std::vector<uint8_t> payload;
};

} // namespace etherforge
