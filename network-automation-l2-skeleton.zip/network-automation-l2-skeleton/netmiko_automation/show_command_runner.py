"""
Run show commands on Cisco IOS devices using Netmiko.

Usage:
    python netmiko_automation/show_command_runner.py
"""

from datetime import datetime
from netmiko import ConnectHandler
from rich import print

from utils import ensure_output_dir, load_devices, load_yaml


def run_show_commands() -> None:
    devices = load_devices()
    commands = load_yaml("netmiko_automation/commands.yml").get("commands", [])
    output_dir = ensure_output_dir()

    for device in devices:
        name = device.get("name", device["host"])
        print(f"[bold cyan]Connecting to {name} ({device['host']})...[/bold cyan]")

        connection_params = {key: value for key, value in device.items() if key != "name"}

        try:
            with ConnectHandler(**connection_params) as conn:
                if device.get("secret"):
                    conn.enable()

                timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
                output_file = output_dir / f"{name}_show_commands_{timestamp}.txt"

                with open(output_file, "w", encoding="utf-8") as file:
                    for command in commands:
                        print(f"  Running: {command}")
                        result = conn.send_command(command)
                        file.write(f"\n\n===== {command} =====\n")
                        file.write(result)
                        file.write("\n")

                print(f"[green]Saved output to {output_file}[/green]")

        except Exception as error:
            print(f"[red]Failed on {name}: {error}[/red]")


if __name__ == "__main__":
    run_show_commands()
