# Netmiko Automation Starters

These scripts are intentionally basic. They are meant to be filled in as your labs get bigger.

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

On Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

## Files

- `devices.yml` - your lab device inventory.
- `commands.yml` - show commands to run.
- `show_command_runner.py` - runs show commands and saves output.
- `backup_configs.py` - saves running-configs.
- `push_config.py` - pushes a config snippet.
- `l2_health_check.py` - starter for switch/VLAN/STP checks.

## First test

```bash
python netmiko_automation/show_command_runner.py
```
