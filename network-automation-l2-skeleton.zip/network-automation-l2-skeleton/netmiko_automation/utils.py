from pathlib import Path
from typing import Any, Dict, List

import yaml


def load_yaml(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as file:
        return yaml.safe_load(file)


def load_devices(path: str = "netmiko_automation/devices.yml") -> List[Dict[str, Any]]:
    data = load_yaml(path)
    return data.get("devices", [])


def ensure_output_dir(path: str = "outputs") -> Path:
    output_dir = Path(path)
    output_dir.mkdir(parents=True, exist_ok=True)
    return output_dir
