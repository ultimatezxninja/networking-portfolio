"""
Layer 2 health-check starter.

This is where you can automate checks for VLANs, trunks, STP, EtherChannel,
and other switching features.
"""

from netmiko import ConnectHandler
from rich import print

from utils import load_devices

L2_COMMANDS = [
    "show vlan brief",
    "show interfaces trunk",
    "show spanning-tree summary",
    "show spanning-tree root",
    "show etherchannel summary",
    "show mac address-table dynamic",
]


def run_l2_health_check() -> None:
    devices = load_devices()

    for device in devices:
        name = device.get("name", device["host"])
        params = {key: value for key, value in device.items() if key != "name"}

        try:
            print(f"\n[bold cyan]L2 health check for {name}[/bold cyan]")
            with ConnectHandler(**params) as conn:
                if device.get("secret"):
                    conn.enable()

                for command in L2_COMMANDS:
                    print(f"\n[bold yellow]{command}[/bold yellow]")
                    print(conn.send_command(command))

        except Exception as error:
            print(f"[red]Health check failed for {name}: {error}[/red]")


if __name__ == "__main__":
    run_l2_health_check()
