"""
Backup running-config from Cisco IOS devices.

Usage:
    python netmiko_automation/backup_configs.py
"""

from datetime import datetime
from netmiko import ConnectHandler
from rich import print

from utils import ensure_output_dir, load_devices


def backup_running_configs() -> None:
    devices = load_devices()
    output_dir = ensure_output_dir()

    for device in devices:
        name = device.get("name", device["host"])
        connection_params = {key: value for key, value in device.items() if key != "name"}

        try:
            print(f"[bold cyan]Backing up {name}...[/bold cyan]")
            with ConnectHandler(**connection_params) as conn:
                if device.get("secret"):
                    conn.enable()

                config = conn.send_command("show running-config")
                timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
                backup_file = output_dir / f"{name}_running_config_{timestamp}.txt"
                backup_file.write_text(config, encoding="utf-8")
                print(f"[green]Saved {backup_file}[/green]")

        except Exception as error:
            print(f"[red]Backup failed for {name}: {error}[/red]")


if __name__ == "__main__":
    backup_running_configs()
