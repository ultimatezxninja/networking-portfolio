"""
Push a config snippet to Cisco IOS devices.

Usage:
    python netmiko_automation/push_config.py configs/basic_hardening.txt
"""

import sys
from pathlib import Path

from netmiko import ConnectHandler
from rich import print

from utils import load_devices


def read_config_lines(config_path: str) -> list[str]:
    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    return [
        line.strip()
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.strip().startswith("!")
    ]


def push_config(config_path: str) -> None:
    commands = read_config_lines(config_path)
    devices = load_devices()

    for device in devices:
        name = device.get("name", device["host"])
        connection_params = {key: value for key, value in device.items() if key != "name"}

        try:
            print(f"[bold cyan]Pushing config to {name}...[/bold cyan]")
            with ConnectHandler(**connection_params) as conn:
                if device.get("secret"):
                    conn.enable()

                output = conn.send_config_set(commands)
                print(output)
                print(f"[green]Config push finished for {name}[/green]")

        except Exception as error:
            print(f"[red]Config push failed for {name}: {error}[/red]")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python netmiko_automation/push_config.py configs/basic_hardening.txt")
        sys.exit(1)

    push_config(sys.argv[1])
