# Network Automation + EtherForge Skeleton

Starter repository for learning network automation with Netmiko and building toward a custom Layer 2 protocol showcase.

## What this repo contains

- `netmiko_automation/` - Python scripts for logging into Cisco IOS devices, running show commands, pushing config, and saving outputs.
- `etherforge_skeleton/` - C++/Linux skeleton for a custom Layer 2 encapsulation protocol using raw Ethernet concepts.
- `configs/` - Example config snippets you can push to routers/switches.
- `outputs/` - Captured command output from automation runs.

## Suggested learning path

1. Get SSH working on one Cisco router or switch.
2. Run `show_command_runner.py` against one device.
3. Expand `devices.yml` to multiple devices.
4. Try `backup_configs.py` to collect running configs.
5. Use `push_config.py` with a small safe config, like banner or hostname.
6. Start filling in the EtherForge C++ protocol files later.

## Safety note

Start with lab devices only. Do not run config-push scripts on production networks.
